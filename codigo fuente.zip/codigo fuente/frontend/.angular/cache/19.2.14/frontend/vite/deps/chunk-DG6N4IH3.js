// node_modules/@angular/cdk/fesm2022/array-I1yfCXUO.mjs
function coerceArray(value) {
  return Array.isArray(value) ? value : [value];
}

export {
  coerceArray
};
//# sourceMappingURL=chunk-DG6N4IH3.js.map
