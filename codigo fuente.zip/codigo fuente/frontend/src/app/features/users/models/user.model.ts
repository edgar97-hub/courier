export interface User {
  id?: string;
  code?: number;
  username: string;
  email: string;
  password?: string;
  rol?: string;
  photo_url?: string;
}
