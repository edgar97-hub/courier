export interface User {
  id: string;
  email?: string;
  name?: string;
  username?: string;
  photo_url?: string;
  role?: string;
  token?: string;
}
