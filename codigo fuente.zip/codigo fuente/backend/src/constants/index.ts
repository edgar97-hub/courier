export { CORS } from './cors';
